// =============================================================================
//   ast.h 
// =============================================================================
// MSU CSE 4714/6714 Capstone Project (Spring 2026)
// Author: Derek Willis
// =============================================================================
#pragma once
#include <memory>
#include <string>
#include <iostream>
#include <vector>
using namespace std;

// -----------------------------------------------------------------------------
// Pretty printer
// -----------------------------------------------------------------------------
inline void ast_line(ostream& os, string prefix, bool last, string label) {
  os << prefix << (last ? "└── " : "├── ") << label << "\n";
}

// TODO: Define and Implement structures to hold each data node!
// Tip: Build with the root of your tree as the lowest struct in this file
//      Implement each higher node in the tree HIGHER up in this file than its children
//      i.e. The root struct at the bottom of the file
//           The leaves of the tree toward the top of the file

struct Statement
{
  // Member Function to Print
  virtual void print_tree(ostream& os,string prefix,bool last) = 0;

  // Member Function to Interpret
  virtual void interpret(ostream& out) = 0;
};

struct Write : Statement
{
  // TODO: Declare Any Member Variables
  string name;

  // Member Function to Print
  void print_tree(ostream& os,string prefix,bool last)override{
    // TODO: Finish this function
    cout << "Write\n";
    ast_line(os, "", false, "name: " + name);
  };

  // Member Function to Interpret
  void interpret(ostream& out)override{
    out << name << endl;
  };
};

struct Compound : Statement
{
  // TODO: Declare Any Member Variables
  vector<unique_ptr<Statement>> statements;

  // Member Function to Print
  void print_tree(ostream& os,string prefix,bool last)override{
    // TODO: Finish this function
    for(auto i = 0; i < (int)statements.size(); i++) {
      if(i == (int)statements.size() - 1) {
        statements[i]->print_tree(os, "", true);
      } else {
        statements[i]->print_tree(os, "", false);
      }
    }
    
  };

  // Member Function to Interpret
  void interpret(ostream& out)override{
    // TODO: Finish this function
    for(auto i = 0; i < (int)statements.size(); i++) {
      if(statements[i]) statements[i]->interpret(out); 
    }
  };
};

// TODO: Finish this struct for Block
struct Block
{
  // TODO: Declare Any Member Variables
  string name;
  unique_ptr<Compound> compound;

  // Member Function to Print
  void print_tree(ostream& os,string prefix,bool last){
    // TODO: Finish this function
    cout << "Block\n";
    ast_line(os, "", false, "name: " + name);
    if (compound) compound->print_tree(os, "", true);
    else 
    { 
      ast_line(os, "", true, "Compound"); 
      ast_line(os, "    ", true, "empty");
    }
  };

  // Member Function to Interpret
  void interpret(ostream& out){
    // TODO: Finish this function
    if (compound) compound->interpret(out); 
  };
};

// You do not need to edit this struct, but can if you choose
struct Program 
{
  // Member Variables
  string name; 
  unique_ptr<Block> block;

  // Member Functions
  void print_tree(ostream& os)
  {
    cout << "Program\n";
    ast_line(os, "", false, "name: " + name);
    if (block) block->print_tree(os, "", true);
    else 
    { 
      ast_line(os, "", true, "Block"); 
      ast_line(os, "    ", true, "(empty)");
    }
  }

  void interpret(ostream& out) 
  { 
    if (block) block->interpret(out); 
  }
};