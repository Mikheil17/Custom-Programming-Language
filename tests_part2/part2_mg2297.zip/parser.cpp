// ============================================================================
//  parser.cpp — Recursive-descent parser 
// ----------------------------------------------------------------------------
// MSU CSE 4714/6714 Capstone Project (Spring 2026)
// Author: Derek Willis
// ============================================================================

#include <memory>
#include <stdexcept>
#include <sstream>
#include <string>
#include <set>
#include "lexer.h"
#include "ast.h"
#include "debug.h"
using namespace std;

// -----------------------------------------------------------------------------
// One-token lookahead
// -----------------------------------------------------------------------------
bool   havePeek = false;
Token  peekTok  = 0;
string peekLex;

inline const char* tname(Token t) { return tokName(t); }

Token peek() 
{
  if (!havePeek) {
    peekTok = yylex();
    if (peekTok == 0) { peekTok = TOK_EOF; peekLex.clear(); }
    else              { peekLex = yytext ? string(yytext) : string(); }
    dbg::line(string("peek: ") + tname(peekTok) + (peekLex.empty() ? "" : " ["+peekLex+"]")
              + " @ line " + to_string(yylineno));
    havePeek = true;
  }
  return peekTok;
}
Token nextTok() 
{
  Token t = peek();
  dbg::line(string("consume: ") + tname(t));
  havePeek = false;
  return t;
}
Token expect(Token want, const char* msg) 
{
  Token got = nextTok();
  if (got != want) {
    dbg::line(string("expect FAIL: wanted ") + tname(want) + ", got " + tname(got));
    ostringstream oss;
    oss << "Parse error (line " << yylineno << "): expected "
        << tname(want) << " — " << msg << ", got " << tname(got)
        << " [" << (yytext ? yytext : "") << "]";
    throw runtime_error(oss.str());
  }
  return got;
}

unique_ptr<Write> parseWrite();
unique_ptr<Read> parseRead();
unique_ptr<Assign> parseAssign();
unique_ptr<Compound> parseCompound();
unique_ptr<Statement> parseStatement();
unique_ptr<Block> parseBlock();
unique_ptr<Program> parseProgram();

pair<Token,string> parsePrimary() {
  Token t = peek();
  if (t == INTLIT || t == FLOATLIT || t == IDENT) {
    string lex = peekLex;
    if (t == IDENT) {
      peek();
      if (symbolTable.find(peekLex) == symbolTable.end())
        throw runtime_error("Undeclared var: " + peekLex);
    }
    nextTok();
    return { t, lex };
  }
  throw runtime_error("Not INTLIT, FLOATLIT, or IDENT");
}

unique_ptr<Write> parseWrite() {
  auto w = make_unique<Write>();
  expect(WRITE, "write");
  expect(OPENPAREN, "open paren");

  Token t = peek();
  if (t == STRINGLIT || t == IDENT) {
    if (t == IDENT && symbolTable.find(peekLex) == symbolTable.end())
      throw runtime_error("Undeclared var: " + peekLex);
    w->content = peekLex;
    w->type    = t;
    nextTok();
  } else {
    throw runtime_error("Not STRINGLIT or IDENT for Write");
  }

  expect(CLOSEPAREN, "close paren");
  return w;
}

unique_ptr<Read> parseRead() {
  auto r = make_unique<Read>();
  expect(READ, "read");
  expect(OPENPAREN, "open paren");

  peek();
  if (symbolTable.find(peekLex) == symbolTable.end())
    throw runtime_error("Undeclared var: " + peekLex);
  r->target = peekLex;
  expect(IDENT, "var name");

  expect(CLOSEPAREN, "close paren");
  return r;
}

unique_ptr<Assign> parseAssign() {
  auto a = make_unique<Assign>();

  peek();
  if (symbolTable.find(peekLex) == symbolTable.end())
    throw runtime_error("Undeclared var: " + peekLex);
  a->id = peekLex;
  expect(IDENT, "var name");
  expect(ASSIGN, ":=");

  auto [vtype, vlex] = parsePrimary();
  a->type = vtype;
  a->value      = vlex;

  return a;
}

unique_ptr<Compound> parseCompound(){
  auto bob = make_unique<Compound>();
  expect(TOK_BEGIN, "token begin");

  bob->statements.push_back(parseStatement());
  while(peek()==SEMICOLON) {
    expect(SEMICOLON, "semicolon");
    bob->statements.push_back(parseStatement());
  }
  expect(END, "end");
  return bob;
}

unique_ptr<Statement> parseStatement(){
  if(peek() == TOK_BEGIN) return parseCompound();
  else if (peek() == READ) return parseRead();
  else if (peek() == WRITE) return parseWrite();
  else if (peek() == IDENT) return parseAssign();
  else throw runtime_error("error");
}

// TODO: implement parsing functions for each grammar in your language
unique_ptr<Block> parseBlock(){

  auto b = make_unique<Block>();

  if (peek() == VAR) {
    nextTok();

    while (peek() == IDENT) {
      string varName = peekLex;
      nextTok();

      if (symbolTable.find(varName) != symbolTable.end())
        throw runtime_error("Duplicate var declaration: " + varName);

      expect(COLON, "colon after var name");

      Token typeToken = peek();
      if (typeToken == INTEGER) {
        symbolTable[varName] = 0;
        nextTok();
      } else if (typeToken == REAL) {
        symbolTable[varName] = 0.0;
        nextTok();
      } else {
        throw runtime_error("Not INTEGER or REAL in declaration");
      }

      expect(SEMICOLON, "semicolon after declaration");
    }
  }

  b->compound = parseCompound();
  return b;
}

// -----------------------------------------------------------------------------
// Program → PROGRAM IDENT ';' Block EOF
// -----------------------------------------------------------------------------
unique_ptr<Program> parseProgram() {
  // Make a pointer to the node we need to build
  auto p = make_unique<Program>();
  // Step through the grammar, storing anything necessary as member variables
  expect(PROGRAM, "start of program");
  expect(IDENT, "program name");
  // Store the program name 
  p->name  = peekLex;
  expect(SEMICOLON, "after program name");
  // Store a pointer to the appropriate block
  p->block = parseBlock();
  expect(TOK_EOF, "at end of file (no trailing tokens after program)");
  // Nothing left in the grammar so we return our node pointer
  return p;
}

// -----------------------------------------------------------------------------
// Parser entry point (called by driver)
// -----------------------------------------------------------------------------
// *****************************************************
// To test piece-wise change the pointer type below
unique_ptr<Program> parse()
// *****************************************************
{
  // Reset lookahead state for a fresh parse
  havePeek = false;
  peekTok = 0;
  peekLex.clear();
  
  // *****************************************************
  // To test piece-wise change the parser function you set as your root
  auto root = parseProgram();
  // *****************************************************

  // Ensure no extra tokens remain
  if (peek() != TOK_EOF) {
    ostringstream oss;
    oss << "Parse error (line " << yylineno << "): extra tokens after <program>, got "
        << tname(peekTok) << " [" << (yytext ? yytext : "") << "]";
    throw runtime_error(oss.str());
  }

  return root;
}