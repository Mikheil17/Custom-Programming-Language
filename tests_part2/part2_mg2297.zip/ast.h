// =============================================================================
//   ast.h 
// =============================================================================
// MSU CSE 4714/6714 Capstone Project (Spring 2026)
// Author: Derek Willis
// =============================================================================
#pragma once
#include <memory>
#include <string>
#include <iostream>
#include <vector>
#include <map>
#include <variant>
using namespace std;

inline map<string, variant<int,double>> symbolTable;


// -----------------------------------------------------------------------------
// Pretty printer
// -----------------------------------------------------------------------------
inline void ast_line(ostream& os, string prefix, bool last, string label) {
  os << prefix << (last ? "└── " : "├── ") << label << "\n";
}



// TODO: Define and Implement structures to hold each data node!
// Tip: Build with the root of your tree as the lowest struct in this file
//      Implement each higher node in the tree HIGHER up in this file than its children
//      i.e. The root struct at the bottom of the file
//           The leaves of the tree toward the top of the file

struct Statement
{
  // Member Function to Print
  virtual void print_tree(ostream& os,string prefix,bool last) = 0;

  // Member Function to Interpret
  virtual void interpret(ostream& out) = 0;
};

struct Assign : Statement
{
  string id;
  Token type;
  string value;

  // Member Function to Print
  void print_tree(ostream& os, string prefix, bool last) override{
    ast_line(os, prefix, last, "Assign Statement");
    string child_prefix = prefix + (last ? "    " : "│   ");
    ast_line(os, child_prefix, false, "Target: " + id);
    ast_line(os, child_prefix, true,  "Value: "  + value);
  }

  // Member Function to Interpret
  void interpret(ostream& out)override{
    (void)out;
    auto& lhs = symbolTable[id];
    visit([&](auto& slot) {
      using T = decay_t<decltype(slot)>;
      if (type == INTLIT) {
        slot = static_cast<T>(stoi(value));
      } else if (type == FLOATLIT) {
        slot = static_cast<T>(stod(value));
      } else { // IDENT
        auto& rhs = symbolTable[value];
        visit([&](auto r){ slot = static_cast<T>(r); }, rhs);
      }
    }, lhs);
  };
};

struct Read : Statement
{
  string target;

  // Member Function to Print
  void print_tree(ostream& os, string prefix, bool last) override{
    ast_line(os, prefix, last, "Read Statement");
    string child_prefix = prefix + (last ? "    " : "│   ");
    ast_line(os, child_prefix, true, "Target: " + target);
  }

  // Member Function to Interpret
  void interpret(ostream& out) override{
    (void)out;
    auto it = symbolTable.find(target);
    visit([&](auto& value) { cin >> value; }, it->second);
  };
};

struct Write : Statement
{
  string content;
  Token type;

  // Member Function to Print
  void print_tree(ostream& os, string prefix, bool last) override{
    ast_line(os, prefix, last, "Write Statement");
    string child_prefix = prefix + (last ? "    " : "│   ");
    ast_line(os, child_prefix, true, "Output: " + content);
  }

  // Member Function to Interpret
  void interpret(ostream& out)override{
    if(type == IDENT) {
      auto it = symbolTable.find(content);
      visit([&out](auto&& value){ out << value << endl; }, it->second);
    } else{
      out << content << endl;
    }
  };
};

struct Compound : Statement
{
  // TODO: Declare Any Member Variables
  vector<unique_ptr<Statement>> statements;

  // Member Function to Print
  void print_tree(ostream& os,string prefix,bool last)override{
    // TODO: Finish this function
    ast_line(os, prefix, last, "Compound Statement");
    string child_prefix = prefix + (last ? "    " : "│   ");
    for(auto i = 0; i < (int)statements.size(); i++) {
      if(i == (int)statements.size() - 1) {
        statements[i]->print_tree(os, child_prefix, true);
      } else {
        statements[i]->print_tree(os, child_prefix, false);
      }
    }
    
  };

  // Member Function to Interpret
  void interpret(ostream& out)override{
    // TODO: Finish this function
    for(auto i = 0; i < (int)statements.size(); i++) {
      if(statements[i]) statements[i]->interpret(out); 
    }
  };
};

// TODO: Finish this struct for Block
struct Block
{
  // TODO: Declare Any Member Variables
  unique_ptr<Compound> compound;

  // Member Function to Print
  void print_tree(ostream& os,string prefix,bool last){
    // TODO: Finish this function
    ast_line(os, prefix, last, "Block");
    string child_prefix = prefix + (last ? "    " : "│   ");
    if (compound) compound->print_tree(os, child_prefix, true);
    else 
    { 
      ast_line(os, child_prefix, true, "Compound Statement");
      ast_line(os, child_prefix + "    ", true, "empty");
    }
  };

  // Member Function to Interpret
  void interpret(ostream& out){
    // TODO: Finish this function
    if (compound) compound->interpret(out); 
  };
};

// You do not need to edit this struct, but can if you choose
struct Program 
{
  // Member Variables
  string name; 
  unique_ptr<Block> block;

  // Member Functions
  void print_tree(ostream& os)
  {
    cout << "Program\n";
    ast_line(os, "", false, "name: " + name);
    if (block) block->print_tree(os, "", true);
    else 
    { 
      ast_line(os, "", true, "Block"); 
      ast_line(os, "    ", true, "(empty)");
    }
  }

  void interpret(ostream& out) 
  { 
    if (block) block->interpret(out); 
  }
};